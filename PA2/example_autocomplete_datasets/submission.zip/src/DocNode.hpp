#ifndef DOCNODE_HPP
#define DOCNODE_HPP
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

//template <typename Data>
class DocNode {
   public:
    /** Constructor.  Initialize a Node with the given Data item,
     *  no parent, and no children.
     */
    Node(const string &d) : data(d) {nextWords = new Vector<string>;}
    const string data;  // the const Data in this node.
    vector<string> * nextWords;

};


#endif  // BSTNODE_HPP
